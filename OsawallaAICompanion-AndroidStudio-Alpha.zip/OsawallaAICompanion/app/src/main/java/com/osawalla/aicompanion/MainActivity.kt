package com.osawalla.aicompanion

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.RecognitionListener
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var heard: TextView
    private lateinit var tts: TextToSpeech
    private var recognizer: SpeechRecognizer? = null
    private var selected = "ChatGPT"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildScreen()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 44)
        }
    }

    private fun buildScreen() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 28)
            gravity = Gravity.TOP
        }
        page.addView(TextView(this).apply {
            text = "Osawalla AI Companion"
            textSize = 26f
        })
        page.addView(TextView(this).apply {
            text = "Separate companion app • Da Echo remains unchanged"
            textSize = 14f
        })
        status = TextView(this).apply {
            text = "Ready — connect your glasses to your phone using Da Echo first."
            textSize = 16f
            setPadding(0, 28, 0, 20)
        }
        page.addView(status)
        val providers = listOf("ChatGPT", "Claude", "Meta AI")
        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, providers)
        spinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                selected = providers[position]
                status.text = "$selected selected. Say “Hey GPT”, “Hey Claude”, or “Hey Meta” after starting voice capture."
            }
        }
        page.addView(spinner)
        val listen = Button(this).apply {
            text = "Start voice command"
            setOnClickListener { startListening() }
        }
        page.addView(listen)
        heard = TextView(this).apply {
            text = "Heard: —"
            textSize = 17f
            setPadding(0, 20, 0, 12)
        }
        page.addView(heard)
        page.addView(TextView(this).apply {
            text = "Voice commands: Hey GPT • Hey Claude • Hey Meta • Switch AI"
            textSize = 14f
        })
        page.addView(TextView(this).apply {
            text = "This alpha shell tests Android speech input and spoken output. AI API connections, background wake-word detection, camera control and glasses-specific Bluetooth commands are not implemented yet."
            textSize = 13f
            setPadding(0, 28, 0, 0)
        })
        setContentView(ScrollView(this).apply { addView(page) })
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "Speech recognition is unavailable on this phone."
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { status.text = "Listening…" }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { status.text = "Processing speech…" }
            override fun onError(error: Int) { status.text = "Speech recognition ended (code $error). Tap to try again." }
            override fun onResults(results: Bundle?) {
                val phrase = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                heard.text = "Heard: $phrase"
                val normalized = phrase.lowercase(Locale.US)
                when {
                    "hey gpt" in normalized || "hey chat gpt" in normalized -> selectAssistant("ChatGPT", "GPT selected. AI connection still needs API setup.")
                    "hey claude" in normalized -> selectAssistant("Claude", "Claude selected. AI connection still needs API setup.")
                    "hey meta" in normalized -> selectAssistant("Meta AI", "Meta selected. AI connection still needs API setup.")
                    "switch ai" in normalized -> askBeforeSwitch()
                    else -> status.text = "Command not recognized. Try Hey GPT, Hey Claude, or Hey Meta."
                }
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        }
        recognizer?.startListening(intent)
    }

    private fun selectAssistant(name: String, message: String) {
        selected = name
        status.text = message
        speak(message)
    }

    private fun askBeforeSwitch() {
        val choices = arrayOf("ChatGPT", "Claude", "Meta AI")
        AlertDialog.Builder(this)
            .setTitle("Switch AI assistant?")
            .setItems(choices) { _, which -> selectAssistant(choices[which], "${choices[which]} selected.") }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun speak(message: String) {
        if (::tts.isInitialized) tts.speak(message, TextToSpeech.QUEUE_FLUSH, null, "osawalla_status")
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) tts.language = Locale.US
    }

    override fun onDestroy() {
        recognizer?.destroy()
        if (::tts.isInitialized) tts.shutdown()
        super.onDestroy()
    }
}
