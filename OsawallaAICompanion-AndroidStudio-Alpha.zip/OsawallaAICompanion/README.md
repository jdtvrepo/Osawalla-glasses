# Osawalla AI Companion — alpha project

This is a **separate Android Studio project**. It does not modify, replace, patch, or re-sign Da Echo.

## Current alpha functionality
- Basic Android app shell.
- One-shot speech recognition after the user taps **Start voice command**.
- Recognizes the phrases `Hey GPT`, `Hey Claude`, `Hey Meta`, and `Switch AI`.
- Android text-to-speech for status prompts.
- A manual assistant picker.

## Not implemented yet
- Live ChatGPT, Claude, or Meta API requests.
- API-key settings / secure key storage.
- Always-on wake-word detection. Android background microphone restrictions mean this needs a foreground-service design and careful battery/privacy handling.
- Direct camera/video shutter control or electrochromic tint control.
- Proprietary Da Echo Bluetooth command integration.
- Automatic failover (the intended behavior is to ask before switching).

## Build
Open this folder in Android Studio (recent version), allow Gradle sync, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

The build environment used to prepare this project did not have Android SDK, Gradle, or adb installed, so an installable APK could not be compiled here. This is source code, not an APK.

## Device test
Install the resulting debug APK on the Pixel 8. Pair/connect the Osawalla glasses using Da Echo first, then test voice recognition and whether Android routes TTS audio to the glasses. This only tests the phone's speech and audio path; it does not establish that Da Echo exposes camera/tint controls to other apps.
